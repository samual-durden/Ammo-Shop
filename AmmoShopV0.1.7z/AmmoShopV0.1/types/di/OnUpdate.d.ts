export declare class OnUpdate {
    onUpdate(timeSinceLastRun: number): boolean;
    getRoute(): string;
}
