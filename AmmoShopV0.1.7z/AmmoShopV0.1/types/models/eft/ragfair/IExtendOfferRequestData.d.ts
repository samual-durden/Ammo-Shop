export interface IExtendOfferRequestData {
    offerId: string;
    renewalTime: number;
}
