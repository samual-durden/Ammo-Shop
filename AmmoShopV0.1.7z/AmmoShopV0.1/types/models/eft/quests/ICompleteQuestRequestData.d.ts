export interface ICompleteQuestRequestData {
    Action: string;
    qid: string;
    removeExcessItems: boolean;
}
