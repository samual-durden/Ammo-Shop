export interface ISearchFriendResponse {
    _id: string;
    Info: Info;
}
export interface Info {
    Nickname: string;
    Side: string;
    Level: number;
}
