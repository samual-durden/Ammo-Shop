export interface ISearchFriendRequestData {
    nickname: string;
}
