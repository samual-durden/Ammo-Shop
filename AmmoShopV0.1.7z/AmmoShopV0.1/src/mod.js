"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const ConfigTypes_1 = require("../../../../Aki_data/Server/lib/models/enums/ConfigTypes");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
class AdvancedTraderFramework {
    constructor() {
        this.modPath = path.normalize(path.join(__dirname, '..'));
    }
    // Perform these actions before server fully loads
    load(container) {
        this.logger = container.resolve("WinstonLogger");
        //Loading Config
        this.modConfig = require("../config/config.json");
        this.modName = this.modConfig.ModName;
        //Loading TraderBase
        let traderBasePath = this.modPath + "/db/base/base.json";
        if (fs.existsSync(traderBasePath)) {
            this.traderBase = require(traderBasePath);
        }
        else {
            this.logger.error(this.modName + "required base.json missing in /db/base/");
        }
        this.logger.debug(`[${this.modName}] Loading... `);
        this.registerProfileImage(container);
        this.setupTraderUpdateTime(container);
    }
    delayedLoad(container) {
        const databaseServer = container.resolve("DatabaseServer");
        const jsonUtil = container.resolve("JsonUtil");
        // Keep a reference to the tables
        const tables = databaseServer.getTables();
        let dialogue = undefined;
        let dialoguePath = this.modPath + "/db/dialogue/dialogue.json";
        if (fs.existsSync(dialoguePath)) {
            dialogue = require(dialoguePath);
        }
        let questassort = undefined;
        let questassortPath = this.modPath + "/db/questassort/questassort.json";
        if (fs.existsSync(questassortPath)) {
            questassort = require(questassortPath);
        }
        // Add the new trader to the trader lists in DatabaseServer
        tables.traders[this.traderBase._id] = {
            assort: this.getAssort(this.logger),
            base: jsonUtil.deserialize(jsonUtil.serialize(this.traderBase)),
            dialogue: dialogue,
            questassort: questassort
        };
        // For each language, add locale for the new trader
        const locales = Object.values(tables.locales.global);
        for (const locale of locales) {
            locale.trading[this.traderBase._id] = {
                FullName: this.traderBase.surname,
                FirstName: this.traderBase.name,
                Nickname: this.traderBase.nickname,
                Location: this.traderBase.location,
                Description: this.traderBase.description
            };
        }
        /* */
        this.logger.debug(`[${this.modName}] Loaded`);
    }
    getAssort(logger) {
        let assort = {
            items: [],
            barter_scheme: {},
            loyal_level_items: {}
        };
        let files = this.loadAssortFiles(this.modPath + "/db/assort/");
        let fileCount = files.length;
        if (fileCount == 0) {
            this.logger.error(this.modName + ": No Files in /db/assort/");
            return assort;
        }
        files.forEach(file => {
            assort = this.mergeAssorts(assort, file);
        });
        this.logger.info(this.modName + ": Loaded " + fileCount + " files.");
        return assort;
    }
    registerProfileImage(container) {
        const resFolderPath = this.modPath + "/res/";
        // Register route pointing to the profile picture
        const imageRouter = container.resolve("ImageRouter");
        //let filename =this.traderBase.avatar.replace(".jpg","");
        let fileExt = ".jpg";
        if (path.extname(this.traderBase.avatar) == ".png")
            fileExt = ".png";
        let fileName = path.basename(this.traderBase.avatar);
        imageRouter.addRoute(this.traderBase.avatar.replace(fileExt, ""), resFolderPath + fileName);
    }
    setupTraderUpdateTime(container) {
        const configServer = container.resolve("ConfigServer");
        const traderConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.TRADER);
        const traderRefreshConfig = {
            traderId: this.traderBase._id,
            seconds: this.modConfig.TraderUpdateTimeInSec
        };
        traderConfig.updateTime.push(traderRefreshConfig);
    }
    loadAssortFiles(filePath) {
        let fileNameList = fs.readdirSync(filePath);
        let fileList = [];
        fileNameList.forEach(fileName => {
            if (path.extname(fileName) == ".json") {
                let newFile = require(filePath + fileName);
                fileList.push(newFile);
            }
        });
        return fileList;
    }
    mergeAssorts(assort1, assort2) {
        Object.values(assort2.items).map((item) => {
            assort1.items.push(item);
            if (item.parentId == "hideout") { //check if its not part of a preset
                assort1.barter_scheme[item._id] = assort2.barter_scheme[item._id];
                assort1.loyal_level_items[item._id] = assort2.loyal_level_items[item._id];
            }
        });
        return assort1;
    }
}
module.exports = { mod: new AdvancedTraderFramework() };
