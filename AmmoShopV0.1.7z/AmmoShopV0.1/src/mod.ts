import { DependencyContainer } from "tsyringe";

// SPT types
import { IMod } from "@spt-aki/models/external/mod";
import { ILogger } from "@spt-aki/models/spt/utils/ILogger";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { ImageRouter } from "@spt-aki/routers/ImageRouter";
import { ConfigServer } from "@spt-aki/servers/ConfigServer";
import { ConfigTypes } from "@spt-aki/models/enums/ConfigTypes";
import { ITraderAssort, ITraderBase } from "@spt-aki/models/eft/common/tables/ITrader";
import { ITraderConfig, UpdateTime } from "@spt-aki/models/spt/config/ITraderConfig";
import { JsonUtil } from "@spt-aki/utils/JsonUtil";
import { ILocaleGlobalBase } from "@spt-aki/models/spt/server/ILocaleBase";
import * as path from 'path';
import * as fs from 'fs';

import { TradeFile } from "./TradeFile";



class AdvancedTraderFramework implements IMod {
    logger: ILogger
    DB: JSON

    modPath: string = path.normalize(path.join(__dirname, '..'));    
    modConfig: JSON
    modName: string

    traderBase: JSON

    constructor() {
    }

    // Perform these actions before server fully loads
    public load(container: DependencyContainer): void {
        this.logger = container.resolve<ILogger>("WinstonLogger");

        //Loading Config
        this.modConfig = require("../config/config.json");
        this.modName = this.modConfig.ModName;

        //Loading TraderBase
        let traderBasePath = this.modPath+"/db/base/base.json";
        if(fs.existsSync(traderBasePath)){
            this.traderBase = require(traderBasePath);
        }
        else{
            this.logger.error(this.modName +"required base.json missing in /db/base/");
        }        

        this.logger.debug(`[${this.modName}] Loading... `);

        this.registerProfileImage(container);
        this.setupTraderUpdateTime(container);

    }

    public delayedLoad(container: DependencyContainer): void {

        
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const jsonUtil = container.resolve<JsonUtil>("JsonUtil");

        // Keep a reference to the tables
        const tables = databaseServer.getTables();

        let dialogue = undefined;
        let dialoguePath = this.modPath+"/db/dialogue/dialogue.json";
        if(fs.existsSync(dialoguePath)){
            dialogue = require(dialoguePath);
        }

        let questassort = undefined;
        let questassortPath = this.modPath+"/db/questassort/questassort.json";
        if(fs.existsSync(questassortPath)){
            questassort = require(questassortPath);
        }
        
        // Add the new trader to the trader lists in DatabaseServer
        tables.traders[this.traderBase._id] = {
            assort: this.getAssort(this.logger),
            base: jsonUtil.deserialize(jsonUtil.serialize(this.traderBase)) as ITraderBase,
            dialogue: dialogue,
            questassort: questassort
        };

        // For each language, add locale for the new trader
        const locales = Object.values(tables.locales.global) as ILocaleGlobalBase[];
        for (const locale of locales) {
            locale.trading[this.traderBase._id] = {
                FullName: this.traderBase.surname,
                FirstName: this.traderBase.name,
                Nickname: this.traderBase.nickname,
                Location: this.traderBase.location,
                Description: this.traderBase.description
            };
        }
        /* */
        this.logger.debug(`[${this.modName}] Loaded`);
    }

    private getAssort(logger:ILogger): ITraderAssort{
        let assort: ITraderAssort = {
            items: [],
            barter_scheme: {},
            loyal_level_items: {}
        };
        let files = this.loadAssortFiles(this.modPath+"/db/assort/");
        let fileCount = files.length;

        if(fileCount == 0){
            this.logger.error(this.modName+": No Files in /db/assort/"); 
            return assort;
        }

        files.forEach(file => {
            assort = this.mergeAssorts(assort,file);
        });
        this.logger.info(this.modName+": Loaded "+fileCount+" files.");     
        return assort;
    }

    private registerProfileImage(container: DependencyContainer): void {
        const resFolderPath = this.modPath+"/res/";
    
        // Register route pointing to the profile picture
        const imageRouter = container.resolve<ImageRouter>("ImageRouter");
        //let filename =this.traderBase.avatar.replace(".jpg","");

        let fileExt = ".jpg";
        if (path.extname(this.traderBase.avatar) == ".png")
        fileExt = ".png";

        let fileName = path.basename(this.traderBase.avatar);

        imageRouter.addRoute(this.traderBase.avatar.replace(fileExt,""),resFolderPath+fileName);
    }

    private setupTraderUpdateTime(container: DependencyContainer): void {
        const configServer = container.resolve<ConfigServer>("ConfigServer");
        const traderConfig = configServer.getConfig<ITraderConfig>(ConfigTypes.TRADER);
        const traderRefreshConfig: UpdateTime = {
            traderId: this.traderBase._id,
            seconds: this.modConfig.TraderUpdateTimeInSec
        };
        traderConfig.updateTime.push(traderRefreshConfig);
    }

    private loadAssortFiles(filePath):Array<ITraderAssort>{
        let fileNameList = fs.readdirSync(filePath);
        let fileList = [];        
        fileNameList.forEach(fileName => {
            if (path.extname(fileName) == ".json"){
                let newFile = require(filePath+fileName) as ITraderAssort;
                fileList.push(newFile);
            }      
        });
        return fileList;
    }

    private mergeAssorts(assort1: ITraderAssort,assort2: ITraderAssort): ITraderAssort{
		Object.values(assort2.items).map((item)=>{	
			assort1.items.push(item);
			if(item.parentId =="hideout"){  //check if its not part of a preset
				assort1.barter_scheme[item._id] = assort2.barter_scheme[item._id];
				assort1.loyal_level_items[item._id] = assort2.loyal_level_items[item._id];
			}				
		});		
		return assort1;
	}

}

module.exports = { mod: new AdvancedTraderFramework() }